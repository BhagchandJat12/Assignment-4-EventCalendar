package com.example.calendar;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity{
    CalendarView calendarView;
    TextView Main;
    Context context ;

    @SuppressLint("SetTextI18n")
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context =getApplicationContext();
        calendarView= (CalendarView)findViewById(R.id.calendarView);
        Main=(TextView)findViewById(R.id.Main);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            String Date;
            if(month<=8 && dayOfMonth<=9){
                Date=year+"-0"+(month+1)+"-0"+dayOfMonth;
            }else if(month<=8 && dayOfMonth>9){
                Date=year+"-0"+(month+1)+"-"+dayOfMonth;
            }else if(month>8 && dayOfMonth<=9){
                Date=year+"-"+(month+1)+"-0"+dayOfMonth;
            }else {
                Date=year+"-"+(month+1)+"-"+dayOfMonth;
            }

            Main.setText(Date+"("+Eventcount.count(Date)+")");


            Main.setOnClickListener( new View.OnClickListener(){
                @Override
                public  void onClick(View v){
                    Toast.makeText(context,  Eventcount.getEvents(Date), Toast.LENGTH_SHORT).show();

                }
            });



        });







    }
}